@javax.xml.bind.annotation.XmlSchema(namespace = "http://businessLogic/")
package service;
